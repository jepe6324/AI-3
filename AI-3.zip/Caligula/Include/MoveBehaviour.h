// MoveBehaviour.h

#ifndef MOVE_BEHAVIOUR_H_INCLUDED
#define MOVE_BEHAVIOUR_H_INCLUDED

#include "BTComposites.h"
#include "Sequence.h"

struct MoveBehaviour : Sequence
{
   MoveBehaviour(BlackBoard* bb);
};

#endif // !MOVE_BEHAVIOUR_H_INCLUDED
