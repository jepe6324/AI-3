// GoblinAttackBehaviour.h

#ifndef GOBLIN_ATTACK_BEHAVIOUR_H_INCLUDED
#define GOBLIN_ATTACK_BEHAVIOUR_H_INCLUDED

#include "BTComposites.h"
#include "Sequence.h"

struct GoblinAttackBehaviour : Sequence
{
   GoblinAttackBehaviour(BlackBoard* bb);
};

#endif // !GOBLIN_ATTACK_BEHAVIOUR_H_INCLUDED
