// BTComposites.h

#ifndef BT_COMPOSITES_H_INCLUDED
#define BT_COMPOSITES_H_INCLUDED

#include "BTNode.h"

// Base Node

struct CompositeNode : Node
{
   std::vector<Node*> children_;

   void Add(Node* node);
};

// Composite Nodes

struct Sequence : CompositeNode
{
   Result Run();
};

struct Selector : CompositeNode
{
   Result Run();
};

struct Parallel : CompositeNode
{
   Result Run();
};

#endif // !BT_COMPOSITES_H_INCLUDED
