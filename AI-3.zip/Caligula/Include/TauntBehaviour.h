// TauntBehaviour.h

#ifndef TAUNT_BEHAVIOUR_H_INCLUDED
#define TAUNT_BEHAVIOUR_H_INCLUDED

#include "BTComposites.h"
#include "Sequence.h"

struct TauntBehaviour : Sequence
{
   TauntBehaviour(BlackBoard* bb);
};

#endif // !TAUNT_BEHAVIOUR_H_INCLUDED
