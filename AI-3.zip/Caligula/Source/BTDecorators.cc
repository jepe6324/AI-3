#include "BTDecorators.h"

void DecoratorNode::SetChild(Node* node)
{
   child_ = node;
}

Node::Result AlwaysSucceed::Run()
{
   child_->Run();
   return SUCCESS;
}

Node::Result Inverter::Run()
{
   Result result = child_->Run();
   if (result == SUCCESS)
   {
      return FAILURE;
   }
   else if (result == FAILURE)
   {
      return SUCCESS;
   }
}
