TANK/KNIGHT
------------------------------------------------------------
The tank will first and foremost focus on drawing the attention of monster by taunting,
taunting will increase the aggro of every monster in range around him.
If he detects that the mage is being focused by a goblin he will walk up to it and 
taunt it.

If he can't taunt or there is no reason to taunt he will try to move towards enemies and 
kill them.

MAGE/HEALER
------------------------------------------------------------
The mage will focus on healing the party, he will only heal a party member when they
have lost enough health to not be overhealed. He always try to stay close to the tank
so that he can be protected and be in range with his heal.

When he can't or won't heal he instead uses ranged attacks against the monsters.

Both humans have a tendency of huddling up close together when they are getting outnumbered.


GOBLIN/MONSTER
------------------------------------------------------------
The goblin has a enmity value for the two humans and will focus it's attacks on the
human with the highest enmity value that isn't super far away.

When a goblin dies 2 more spawn, the humans will always lose.